# 1.0.0 (25 March 2017)

* [+] First release of the "Welcome - Business Server" extension
