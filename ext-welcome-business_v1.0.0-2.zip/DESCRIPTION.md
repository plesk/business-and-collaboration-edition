# Welcome - Business Server

This extension helps you to get started with your new Plesk Business Server!

Let Elvis - Plesk's smart octopus mascot - help you with all important steps in the beginning of your Plesk journey.